﻿using System.ComponentModel.DataAnnotations;

namespace lab3It.Models
{
    public class Patient
    {

        [Key]
        public int PatientId { get; set; }

        [Required]
        public string name { get; set; }

        [Required]
        [Range(10000, 99999)]
        [Display(Name = "Code of patient")]
        public int PatientCode { get; set; }

        public ICollection<DoctorPatient> DoctorPatients { get; set; } = new List<DoctorPatient>();

        [Required]
         [EnumDataType(typeof(Gender))]
        public Gender SelectedGender { get; set; }

        public enum Gender
        {
            Male,
            Female
        }



    }
}
