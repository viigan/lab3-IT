﻿using System.ComponentModel.DataAnnotations;

namespace lab3It.Models
{
    public class Doctor
    {
        [Key]
        public int DoctorId { get; set; }

        [Required]
        public string name { get; set; }

        public Hospital? Hospital { get; set; }
        public int? HospitalId { get; set; }

        public ICollection<DoctorPatient> DoctorPatients { get; set; } = new List<DoctorPatient>();



    }
}
