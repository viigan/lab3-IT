﻿using System.ComponentModel.DataAnnotations;

namespace lab3It.Models
{
   


        public enum Gender
        {
            Male,
            Female
        }

}
