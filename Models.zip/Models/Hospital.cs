﻿using System.ComponentModel.DataAnnotations;

namespace lab3It.Models
{
    public class Hospital
    {
        [Key]
        public int HospitalId { get; set; }

        [Required]
        public string Name { get; set; }
        

        [Display(Name = "Image of Hospital")]
        public string ImageUrl { get; set; }


        public ICollection<Doctor> Doctors { get; set; } = new List<Doctor>();


   
    }
}
